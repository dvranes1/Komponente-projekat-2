package com.reservations.users.NotificationService.dto;
import lombok.*;

import java.util.Map;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class NotificationRequestDto {

    private String notificationTypeName;

    private String email;

    private Map<String, String> params;
}
