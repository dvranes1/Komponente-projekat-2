package com.reservations.users.NotificationService.messaging;

import com.reservations.users.NotificationService.dto.NotificationRequestDto;
import com.reservations.users.NotificationService.service.NotificationService;
import lombok.AllArgsConstructor;
import org.springframework.amqp.rabbit.annotation.RabbitListener;
import org.springframework.stereotype.Component;

@Component
@AllArgsConstructor
public class NotificationListener {

    private final NotificationService notificationService;

    @RabbitListener(queues = "notifications")
    public void handleNotificationRequest(NotificationRequestDto request) {
        notificationService.processNotification(request);
    }


}
