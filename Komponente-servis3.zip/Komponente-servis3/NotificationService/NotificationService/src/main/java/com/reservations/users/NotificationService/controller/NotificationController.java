package com.reservations.users.NotificationService.controller;

import com.reservations.users.NotificationService.domain.Notification;
import com.reservations.users.NotificationService.repositories.NotificationRepository;
import com.reservations.users.NotificationService.security.CheckSecurity;
import com.reservations.users.NotificationService.security.service.Impl.TokenServiceImpl;
import com.reservations.users.NotificationService.security.service.TokenService;
import io.jsonwebtoken.Claims;
import lombok.AllArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDateTime;
import java.util.List;
import java.util.stream.Collectors;

@RestController
@RequestMapping("/api/notifications")
public class NotificationController {

    private final TokenService tokenService;
    private final NotificationRepository notificationRepository;

    public NotificationController(TokenService tokenService, NotificationRepository notificationRepository) {
        this.tokenService = tokenService;
        this.notificationRepository = notificationRepository;
    }

    @CheckSecurity(roles = {"ADMIN"})
    @GetMapping("/all")
    public List<Notification> getAllNotifications(@RequestHeader("Authorization") String authorization) {
        return notificationRepository.findAll();
    }

    @CheckSecurity(roles = {"ADMIN"})
    @GetMapping("/type/{typeName}")
    public List<Notification> getByType(@RequestHeader("Authorization") String authorization, @PathVariable String typeName) {
        return notificationRepository.findAllByNotificationType_Name(typeName);
    }

    @CheckSecurity(roles = {"ADMIN"})
    @GetMapping("/email/{email}")
    public List<Notification> getByEmail(@RequestHeader("Authorization") String authorization, @PathVariable String email) {
        return notificationRepository.findAllByEmail(email);
    }

    @CheckSecurity(roles = {"ADMIN"})
    @GetMapping("/date-range")
    public List<Notification> getByDateRange(@RequestHeader("Authorization") String authorization,
                                             @RequestParam("start") String start,
                                             @RequestParam("end") String end) {
        LocalDateTime startTime = LocalDateTime.parse(start);
        LocalDateTime endTime = LocalDateTime.parse(end);
        return notificationRepository.findAllBySentAtBetween(startTime, endTime);
    }

    @CheckSecurity(roles = {"CLIENT", "MANAGER"})
    @GetMapping("/my")
    public List<Notification> getMyNotifications(@RequestHeader("Authorization") String authorization) {
        String token = extractBearerToken(authorization);
        Claims claims = tokenService.parseToken(token);
        String userEmail = claims.getSubject();
        return notificationRepository.findAllByEmail(userEmail);
    }

    @CheckSecurity(roles = {"CLIENT", "MANAGER"})
    @GetMapping("/my/type/{typeName}")
    public List<Notification> getMyNotificationsByType(
            @RequestHeader("Authorization") String authorization,
            @PathVariable String typeName
    ) {
        String token = extractBearerToken(authorization);
        Claims claims = tokenService.parseToken(token);
        String userEmail = claims.getSubject();

        return notificationRepository.findAllByNotificationType_Name(typeName)
                .stream()
                .filter(n -> n.getEmail().equalsIgnoreCase(userEmail))
                .collect(Collectors.toList());
    }

    @CheckSecurity(roles = {"CLIENT", "MANAGER"})
    @GetMapping("/my/date-range")
    public List<Notification> getMyNotificationsByDateRange(
            @RequestHeader("Authorization") String authorization,
            @RequestParam("start") String start,
            @RequestParam("end") String end
    ) {
        String token = extractBearerToken(authorization);
        Claims claims = tokenService.parseToken(token);
        String userEmail = claims.getSubject();

        LocalDateTime startTime = LocalDateTime.parse(start);
        LocalDateTime endTime = LocalDateTime.parse(end);

        return notificationRepository.findAllBySentAtBetween(startTime, endTime)
                .stream()
                .filter(n -> n.getEmail().equalsIgnoreCase(userEmail))
                .collect(Collectors.toList());
    }

    private String extractBearerToken(String authorizationHeader) {
        if (authorizationHeader == null || !authorizationHeader.startsWith("Bearer ")) {
            throw new RuntimeException("Missing or invalid Authorization header");
        }
        return authorizationHeader.substring(7).trim();
    }
}
