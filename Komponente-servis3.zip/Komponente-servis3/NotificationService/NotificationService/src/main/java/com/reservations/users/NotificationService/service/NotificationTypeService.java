package com.reservations.users.NotificationService.service;

import com.reservations.users.NotificationService.domain.NotificationType;
import com.reservations.users.NotificationService.dto.NotificationTypeDto;

import java.util.List;
import java.util.UUID;

public interface NotificationTypeService {
    NotificationType createType(NotificationTypeDto dto);
    List<NotificationType> getAllTypes();
    NotificationType updateType(UUID id, NotificationTypeDto dto);
    void deleteType(UUID id);
}
