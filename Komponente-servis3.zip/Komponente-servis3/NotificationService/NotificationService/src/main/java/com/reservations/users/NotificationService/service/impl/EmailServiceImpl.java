package com.reservations.users.NotificationService.service.impl;

import com.reservations.users.NotificationService.service.EmailService;
import jakarta.mail.MessagingException;
import jakarta.mail.internet.MimeMessage;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.lang.Nullable;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.stereotype.Service;

import java.util.Map;

@Service
public class EmailServiceImpl implements EmailService {

    @Value("${spring.mail.username}")
    private String from;

    @Autowired
    private JavaMailSender javaMailSender;

    @Override
    public boolean sendMail(String to,
                            @Nullable String[] cc,
                            String subject,
                            String body,
                            Map<String, String> params) {
        try {
            switch (subject) {
                case "REGISTRATION_CONFIRMATION":
                    return sendRegistrationConfirmation(to, cc, body, params);

                case "PASSWORD_RESET":
                    return sendPasswordReset(to, cc, body, params);

                case "RESERVATION_SUCCESS":
                    return sendReservationSuccess(to, cc, body, params);

                case "RESERVATION_CANCELLED":
                    return sendReservationCancelled(to, cc, body, params);

                case "RESERVATION_REMINDER":
                    return sendReservationReminder(to, cc, body, params);

                default:
                    return sendGenericEmail(to, cc, "Generic notification", body, params);
            }
        } catch (MessagingException e) {
            e.printStackTrace();
            return false;
        }
    }

    private boolean sendRegistrationConfirmation(String to, String[] cc, String body, Map<String, String> params)
            throws MessagingException {

        String firstName = params.get("firstName");
        String activationLink = params.get("activationLink");

        String finalSubject = "Potvrda registracije";
        String htmlContent = "<h3>Pozdrav, " + firstName + "!</h3>"
                + "<p>Za potvrdu registracije kliknite na link:</p>"
                + "<a href=\"" + activationLink + "\">Aktiviraj nalog</a>";

        return sendHtmlEmail(to, cc, finalSubject, htmlContent);
    }

    private boolean sendPasswordReset(String to, String[] cc, String body, Map<String, String> params)
            throws MessagingException {

        String resetLink = params.get("resetLink");

        String finalSubject = "Promena lozinke";
        String htmlContent = "<p>Da biste resetovali lozinku, kliknite na link:</p>"
                + "<a href=\"" + resetLink + "\">Reset lozinke</a>";

        return sendHtmlEmail(to, cc, finalSubject, htmlContent);
    }

    private boolean sendReservationSuccess(String to, String[] cc, String body, Map<String, String> params)
            throws MessagingException {

        String date = params.get("date");
        String time = params.get("time");
        String restaurant = params.get("restaurant");

        String finalSubjectClient = "Rezervacija uspešno napravljena!";
        String htmlContentClient = "<p>Poštovani, vaša rezervacija za " + date + " u " + time
                + " je uspešno kreirana!</p>"
                + "<p>Vidimo se u restoranu <b>" + restaurant + "</b>.</p>";


        boolean clientResult = sendHtmlEmail(to, cc, finalSubjectClient, htmlContentClient);


        return clientResult;
    }

    private boolean sendReservationCancelled(String to, String[] cc, String body, Map<String, String> params)
            throws MessagingException {

        String managerEmail = params.get("managerEmail");
        String cancelledBy = params.get("cancelledBy");
        String date = params.get("date");
        String time = params.get("time");

        String finalSubject = "Otkazivanje rezervacije";
        String htmlContent = "<p>Otkazana je rezervacija za datum: <b>" + date
                + "</b> i vreme: <b>" + time + "</b>.</p>";

        if ("MANAGER".equalsIgnoreCase(cancelledBy)) {
            return sendHtmlEmail(to, cc, finalSubject, htmlContent);
        } else {
            return sendHtmlEmail(managerEmail, cc, finalSubject, htmlContent);
        }
    }

    private boolean sendReservationReminder(String to, String[] cc, String body, Map<String, String> params)
            throws MessagingException {

        String date = params.get("date");
        String time = params.get("time");
        String finalSubject = "Podsetnik za rezervaciju";
        String htmlContent = "<p>Podsećamo vas da imate rezervaciju za <b>"
                + date + "</b> u <b>" + time + "</b>, za oko 1 sat.</p>";

        return sendHtmlEmail(to, cc, finalSubject, htmlContent);
    }

    private boolean sendGenericEmail(String to, String[] cc, String finalSubject, String body, Map<String, String> params)
            throws MessagingException {
        String htmlContent = "<p>" + body + "</p>";
        return sendHtmlEmail(to, cc, finalSubject, htmlContent);
    }

    private boolean sendHtmlEmail(String to, String[] cc, String finalSubject, String htmlBody)
            throws MessagingException {
        MimeMessage message = javaMailSender.createMimeMessage();
        MimeMessageHelper helper = new MimeMessageHelper(message, true, "UTF-8");

        helper.setFrom(from);
        helper.setTo(to);

        if (cc != null && cc.length > 0) {
            helper.setCc(cc);
        }

        helper.setSubject(finalSubject);
        helper.setText(htmlBody, true);
        javaMailSender.send(message);

        return true;
    }
}
