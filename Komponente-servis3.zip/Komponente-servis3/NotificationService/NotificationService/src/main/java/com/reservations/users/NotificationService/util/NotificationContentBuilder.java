package com.reservations.users.NotificationService.util;
import java.util.Map;

public class NotificationContentBuilder {

    private NotificationContentBuilder() {
    }

    public static String buildContent(String template, Map<String, String> params) {
        String content = template;
        if (params != null) {
            for (Map.Entry<String, String> entry : params.entrySet()) {
                String placeholder = "%" + entry.getKey();
                content = content.replace(placeholder, entry.getValue());
            }
        }
        return content;
    }
}
