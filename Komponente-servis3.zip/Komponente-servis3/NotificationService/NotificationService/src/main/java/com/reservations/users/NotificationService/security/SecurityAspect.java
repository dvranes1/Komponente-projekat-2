package com.reservations.users.NotificationService.security;

import com.reservations.users.NotificationService.security.service.TokenService;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.reflect.MethodSignature;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import java.lang.reflect.Method;
import java.util.Arrays;
import io.jsonwebtoken.Claims;

@Aspect
@Configuration
public class SecurityAspect {

    private final TokenService tokenService;

    public SecurityAspect(TokenService tokenService) {
        this.tokenService = tokenService;
    }

    @Around("@annotation(com.reservations.users.NotificationService.security.CheckSecurity)")
    public Object around(ProceedingJoinPoint joinPoint) throws Throwable {
        MethodSignature methodSignature = (MethodSignature) joinPoint.getSignature();
        Method method = methodSignature.getMethod();


        System.out.println("Intercepting method: " + method.getName());

        String token = null;
        Object[] args = joinPoint.getArgs();
        String[] parameterNames = methodSignature.getParameterNames();

        for (int i = 0; i < parameterNames.length; i++) {
            if ("authorization".equalsIgnoreCase(parameterNames[i]) && args[i] instanceof String) {
                String headerValue = (String) args[i];
                System.out.println("Authorization header: " + headerValue);
                if (headerValue.startsWith("Bearer ")) {
                    token = headerValue.substring(7).trim();
                }
            }
        }

        if (token == null || token.isEmpty()) {
            System.out.println("Token not found or empty.");
            return new ResponseEntity<>("Missing or invalid token", HttpStatus.UNAUTHORIZED);
        }

        if (!token.matches("[a-zA-Z0-9-_]+\\.[a-zA-Z0-9-_]+\\.[a-zA-Z0-9-_]+")) {
            System.out.println("Invalid token format.");
            return new ResponseEntity<>("Invalid token format", HttpStatus.UNAUTHORIZED);
        }

        Claims claims;
        try {
            claims = tokenService.parseToken(token);
            if (claims == null) {
                throw new RuntimeException("Token claims are null");
            }
            System.out.println("Token claims: " + claims);
        } catch (Exception e) {
            throw new RuntimeException("Failed to parse token: " + e.getMessage());
        }


        CheckSecurity checkSecurity = method.getAnnotation(CheckSecurity.class);
        String role = claims.get("role", String.class);
        if (role == null) {
            System.out.println("Role not found in token.");
            return new ResponseEntity<>("Role not found in token", HttpStatus.FORBIDDEN);
        }

        System.out.println("Required roles: " + Arrays.toString(checkSecurity.roles()));
        System.out.println("User role from token: " + role);

        if (!Arrays.asList(checkSecurity.roles()).contains(role)) {
            System.out.println("Access denied: Role not authorized.");
            return new ResponseEntity<>("Access denied", HttpStatus.FORBIDDEN);
        }

        System.out.println("Access granted. Proceeding with method execution.");
        return joinPoint.proceed();
    }
}