package com.reservations.users.NotificationService.service;

import com.reservations.users.NotificationService.dto.NotificationRequestDto;

public interface NotificationService {
    void processNotification(NotificationRequestDto request);
}
