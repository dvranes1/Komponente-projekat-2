package com.reservations.users.NotificationService.service;

import java.util.Map;

public interface EmailService {

    boolean sendMail(String to, String[] cc, String subject, String body, Map<String, String> params);

}
