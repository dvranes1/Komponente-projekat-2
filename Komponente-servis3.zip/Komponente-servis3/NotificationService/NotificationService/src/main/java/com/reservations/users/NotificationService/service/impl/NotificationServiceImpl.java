package com.reservations.users.NotificationService.service.impl;

import com.reservations.users.NotificationService.domain.Notification;
import com.reservations.users.NotificationService.domain.NotificationType;
import com.reservations.users.NotificationService.dto.NotificationRequestDto;
import com.reservations.users.NotificationService.repositories.NotificationRepository;
import com.reservations.users.NotificationService.repositories.NotificationTypeRepository;
import com.reservations.users.NotificationService.service.EmailService;
import com.reservations.users.NotificationService.service.NotificationService;
import com.reservations.users.NotificationService.util.NotificationContentBuilder;
import lombok.AllArgsConstructor;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;

@Service
@AllArgsConstructor
public class NotificationServiceImpl implements NotificationService {
    private final NotificationTypeRepository notificationTypeRepository;
    private final NotificationRepository notificationRepository;
    private final EmailService emailSenderService;

    @Override
    public void processNotification(NotificationRequestDto request) {
        NotificationType notificationType = notificationTypeRepository
                .findByName(request.getNotificationTypeName())
                .orElseThrow(() -> new RuntimeException(
                        "NotificationType not found: " + request.getNotificationTypeName()
                ));

        String content = NotificationContentBuilder.buildContent(
                notificationType.getTemplate(),
                request.getParams()
        );

        emailSenderService.sendMail(request.getEmail(), null, request.getNotificationTypeName(), content, request.getParams());

        Notification newNotification = Notification.builder()
                .notificationType(notificationType)
                .email(request.getEmail())
                .content(content)
                .sentAt(LocalDateTime.now())
                .build();


        notificationRepository.save(newNotification);
    }
}
