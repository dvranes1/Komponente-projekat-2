package com.reservations.users.NotificationService.controller;

import com.reservations.users.NotificationService.domain.NotificationType;
import com.reservations.users.NotificationService.dto.NotificationTypeDto;
import com.reservations.users.NotificationService.security.CheckSecurity;
import com.reservations.users.NotificationService.service.NotificationTypeService;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.UUID;

@RestController
@RequestMapping("/api/admin/notification-types")
public class NotificationTypeController {

    private final NotificationTypeService notificationTypeService;

    public NotificationTypeController(NotificationTypeService notificationTypeService) {
        this.notificationTypeService = notificationTypeService;
    }

    @CheckSecurity(roles = {"ADMIN"})
    @PostMapping
    public ResponseEntity<NotificationType> create(@RequestHeader("Authorization") String authorization,@RequestBody NotificationTypeDto dto) {
        NotificationType notificationType =  notificationTypeService.createType(dto);
        return new ResponseEntity<>(notificationType, HttpStatus.CREATED);
    }

    @CheckSecurity(roles = {"ADMIN"})
    @GetMapping
    public ResponseEntity<List<NotificationType>> getAll(@RequestHeader("Authorization") String authorization) {
       List<NotificationType> notificationTypeList =  notificationTypeService.getAllTypes();
       return new ResponseEntity<>(notificationTypeList, HttpStatus.OK);
    }

    @CheckSecurity(roles = {"ADMIN"})
    @PutMapping("/{id}")
    public ResponseEntity<NotificationType> update(@RequestHeader("Authorization") String authorization,@PathVariable UUID id, @RequestBody NotificationTypeDto dto) {
        NotificationType notificationTypeUpdate = notificationTypeService.updateType(id, dto);
        return new ResponseEntity<>(notificationTypeUpdate, HttpStatus.OK);
    }

    @CheckSecurity(roles = {"ADMIN"})
    @DeleteMapping("/{id}")
    public void delete(@RequestHeader("Authorization") String authorization,@PathVariable UUID id) {
        notificationTypeService.deleteType(id);
    }
}