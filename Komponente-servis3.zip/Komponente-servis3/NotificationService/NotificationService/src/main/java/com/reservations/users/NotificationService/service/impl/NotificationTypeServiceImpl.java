package com.reservations.users.NotificationService.service.impl;

import com.reservations.users.NotificationService.domain.NotificationType;
import com.reservations.users.NotificationService.dto.NotificationTypeDto;
import com.reservations.users.NotificationService.repositories.NotificationTypeRepository;
import com.reservations.users.NotificationService.service.NotificationTypeService;
import lombok.AllArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.UUID;

@Service
@AllArgsConstructor
public class NotificationTypeServiceImpl implements NotificationTypeService {
    private final NotificationTypeRepository notificationTypeRepository;
    @Override
    public NotificationType createType(NotificationTypeDto dto) {
        NotificationType notificationType = NotificationType.builder()
                .name(dto.getName())
                .template(dto.getTemplate())
                .description(dto.getDescription())
                .build();
        return notificationTypeRepository.save(notificationType);
    }

    @Override
    public List<NotificationType> getAllTypes() {
        return notificationTypeRepository.findAll();
    }

    @Override
    public NotificationType updateType(UUID id, NotificationTypeDto dto) {
        NotificationType existing = notificationTypeRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("NotificationType not found!"));
        existing.setName(dto.getName());
        existing.setTemplate(dto.getTemplate());
        existing.setDescription(dto.getDescription());
        return notificationTypeRepository.save(existing);
    }

    @Override
    public void deleteType(UUID id) {
        notificationTypeRepository.deleteById(id);
    }
}
