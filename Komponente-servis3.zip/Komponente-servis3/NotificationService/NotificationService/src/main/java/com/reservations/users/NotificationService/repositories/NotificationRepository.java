package com.reservations.users.NotificationService.repositories;
import com.reservations.users.NotificationService.domain.Notification;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.time.LocalDateTime;
import java.util.List;
import java.util.UUID;

@Repository
public interface NotificationRepository extends JpaRepository<Notification, UUID> {
    List<Notification> findAllByNotificationType_Name(String typeName);

    List<Notification> findAllByEmail(String email);

    List<Notification> findAllBySentAtBetween(LocalDateTime start, LocalDateTime end);
}
