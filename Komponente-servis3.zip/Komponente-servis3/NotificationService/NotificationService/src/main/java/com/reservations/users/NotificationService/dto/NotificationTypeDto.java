package com.reservations.users.NotificationService.dto;
import lombok.*;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class NotificationTypeDto {

    private String name;
    private String template;
    private String description;
}

