package com.reservations.users.NotificationService.repositories;
import com.reservations.users.NotificationService.domain.NotificationType;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.Optional;
import java.util.UUID;

@Repository
public interface NotificationTypeRepository extends JpaRepository<NotificationType, UUID> {
    Optional<NotificationType> findByName(String name);
}
