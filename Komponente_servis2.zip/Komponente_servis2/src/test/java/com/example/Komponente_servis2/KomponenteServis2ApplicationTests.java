package com.example.Komponente_servis2;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class KomponenteServis2ApplicationTests {

	@Test
	void contextLoads() {
	}

}
