package com.example.Komponente_servis2.domain;

public enum RestaurantZone {
    INDOOR,
    OUTDOOR,
    SMOKING,
    NON_SMOKING,
    BALCON;
}
