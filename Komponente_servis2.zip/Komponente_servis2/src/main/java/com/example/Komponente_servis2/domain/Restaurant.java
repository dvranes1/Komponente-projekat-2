package com.example.Komponente_servis2.domain;

import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.OneToMany;

import java.util.List;
@Entity
public class Restaurant extends BaseEntity {
    private String name;
    private String address;
    private String description;
    private int seats;
    private String openHours;
    @Enumerated(EnumType.STRING)
    private CuisineType cuisineType;
    @OneToMany(mappedBy = "restaurant")
    private List<Reservation> reservationList;
    private int availableSeats;

    public Restaurant() {
    }

    public Restaurant(Long id, String name, String address, String description, int seats, String openHours, CuisineType cuisineType, int availableSeats) {
        super(id);
        this.name = name;
        this.address = address;
        this.description = description;
        this.seats = seats;
        this.openHours = openHours;
        this.cuisineType = cuisineType;
        this.availableSeats = availableSeats;
    }

    public Restaurant(String name, String address, String description, int seats, String openHours, CuisineType cousineType,int availableSeats) {
        this.name = name;
        this.address = address;
        this.description = description;
        this.seats = seats;
        this.openHours = openHours;
        this.cuisineType = cousineType;
        this.availableSeats = availableSeats;
    }


    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public int getSeats() {
        return seats;
    }

    public void setSeats(int seats) {
        this.seats = seats;
        this.availableSeats = seats;
    }

    public String getOpenHours() {
        return openHours;
    }

    public void setOpenHours(String openHours) {
        this.openHours = openHours;
    }

    public CuisineType getCuisineType() {
        return cuisineType;
    }

    public void setCuisineType(CuisineType cuisineType) {
        this.cuisineType = cuisineType;
    }

    public List<Reservation> getReservationList() {
        return reservationList;
    }

    public void setReservationList(List<Reservation> reservationList) {
        this.reservationList = reservationList;
    }

    public int getAvailableSeats() {
        return availableSeats;
    }

    public void setAvailableSeats(int availableSeats) {
        this.availableSeats = availableSeats;
    }
}
