package com.example.Komponente_servis2.dto;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.*;

import java.util.Map;


@Builder
public class NotificationRequestDto {

    private String notificationTypeName;

    private String email;

    private Map<String, String> params;

    public NotificationRequestDto(String notificationTypeName, String email, Map<String, String> params) {
        this.notificationTypeName = notificationTypeName;
        this.email = email;
        this.params = params;
    }
    public NotificationRequestDto() {

    }

    public String getNotificationTypeName() {
        return notificationTypeName;
    }

    public void setNotificationTypeName(String notificationTypeName) {
        this.notificationTypeName = notificationTypeName;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public Map<String, String> getParams() {
        return params;
    }

    public void setParams(Map<String, String> params) {
        this.params = params;
    }

    @Override
    public String toString() {
        try {
            ObjectMapper objectMapper = new ObjectMapper();
            return objectMapper.writeValueAsString(this);
        } catch (JsonProcessingException e) {
            throw new RuntimeException("Error serializing NotificationRequestDto to JSON", e);
        }
    }
}
