package com.example.Komponente_servis2.domain;

import jakarta.persistence.*;

import java.time.LocalDateTime;

@Entity
public class AvailableTerm extends BaseEntity {

    @ManyToOne
    @JoinColumn(name = "restaurant_id")
    private Restaurant restaurant;

    private int numberOfSeats;

    @Enumerated(EnumType.STRING)
    private RestaurantZone zone;

    private LocalDateTime startTime;

    private LocalDateTime endTime;

    private boolean available;


    public AvailableTerm(Long id, Restaurant restaurant, int numberOfSeats, RestaurantZone zone, LocalDateTime startTime, LocalDateTime endTime, boolean available) {
        super(id);
        this.restaurant = restaurant;
        this.numberOfSeats = numberOfSeats;
        this.zone = zone;
        this.startTime = startTime;
        this.endTime = endTime;
        this.available = available;
    }

    public AvailableTerm(Restaurant restaurant, int numberOfSeats, RestaurantZone zone, LocalDateTime startTime, LocalDateTime endTime, boolean available) {
        this.restaurant = restaurant;
        this.numberOfSeats = numberOfSeats;
        this.zone = zone;
        this.startTime = startTime;
        this.endTime = endTime;
        this.available = available;
    }

    public AvailableTerm() {
    }

    public Restaurant getRestaurant() {
        return restaurant;
    }

    public void setRestaurant(Restaurant restaurant) {
        this.restaurant = restaurant;
    }

    public int getNumberOfSeats() {
        return numberOfSeats;
    }

    public void setNumberOfSeats(int numberOfSeats) {
        this.numberOfSeats = numberOfSeats;
    }

    public RestaurantZone getZone() {
        return zone;
    }

    public void setZone(RestaurantZone zone) {
        this.zone = zone;
    }

    public LocalDateTime getStartTime() {
        return startTime;
    }

    public void setStartTime(LocalDateTime startTime) {
        this.startTime = startTime;
    }

    public LocalDateTime getEndTime() {
        return endTime;
    }

    public void setEndTime(LocalDateTime endTime) {
        this.endTime = endTime;
    }

    public boolean isAvailable() {
        return available;
    }

    public void setAvailable(boolean available) {
        this.available = available;
    }
}