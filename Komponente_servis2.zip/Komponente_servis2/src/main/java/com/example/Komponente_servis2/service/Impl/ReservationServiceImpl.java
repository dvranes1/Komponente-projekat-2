package com.example.Komponente_servis2.service.Impl;

import com.example.Komponente_servis2.domain.AvailableTerm;
import com.example.Komponente_servis2.domain.Reservation;
import com.example.Komponente_servis2.domain.Restaurant;
import com.example.Komponente_servis2.domain.RestaurantZone;
import com.example.Komponente_servis2.dto.AvailableTermDto;
import com.example.Komponente_servis2.dto.NotificationRequestDto;
import com.example.Komponente_servis2.dto.ReservationDto;
import com.example.Komponente_servis2.mapper.AvailableTermMapper;
import com.example.Komponente_servis2.mapper.ReservationMapper;
import com.example.Komponente_servis2.repository.AvailableTermRepository;
import com.example.Komponente_servis2.repository.ReservationRepository;
import com.example.Komponente_servis2.repository.RestaurantRepository;
import com.example.Komponente_servis2.service.AvailableTermService;
import com.example.Komponente_servis2.service.ReservationService;
import jakarta.transaction.Transactional;
import org.springframework.amqp.rabbit.core.RabbitTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@Service
@Transactional
public class ReservationServiceImpl implements ReservationService {
    private final ReservationRepository reservationRepository;
    private final RestaurantRepository restaurantRepository;
    private final ReservationMapper reservationMapper;
    private final AvailableTermMapper availableTermMapper;
    private final RabbitTemplate rabbitTemplate;
    private final AvailableTermRepository availableTermRepository;
    @Autowired
    private final RestTemplate userServiceRestTemplate;

    public ReservationServiceImpl(ReservationRepository reservationRepository, RestaurantRepository restaurantRepository,
                                  ReservationMapper reservationMapper, AvailableTermMapper availableTermMapper, RestTemplate userServiceRestTemplate,RabbitTemplate rabbitTemplate,AvailableTermRepository availableTermRepository) {
        this.reservationRepository = reservationRepository;
        this.restaurantRepository = restaurantRepository;
        this.reservationMapper = reservationMapper;
        this.availableTermMapper = availableTermMapper;
        this.userServiceRestTemplate = userServiceRestTemplate;
        this.rabbitTemplate = rabbitTemplate;
        this.availableTermRepository = availableTermRepository;
    }
    @Override
    public ReservationDto createReservation(ReservationDto reservationDto) {
        Long clientId = reservationDto.getClientId();

        Integer previousReservationCount;
        try {
            previousReservationCount = getReservationCount(clientId);
        } catch (Exception e) {
            throw new RuntimeException("Failed to get reservation count", e);
        }

        if (previousReservationCount != null && previousReservationCount >= 10) {
            throw new RuntimeException("Failed to get previous res count");
        }

        Restaurant restaurant = restaurantRepository.findById(reservationDto.getRestaurantId())
                .orElseThrow(() -> new RuntimeException("Restaurant failed to be found"));

        if (restaurant.getAvailableSeats() < reservationDto.getPeopleNumber()) {
            throw new RuntimeException("Not enough free space in restaurant");
        }

        Reservation reservation = reservationMapper.getDomainFromDto(reservationDto);
        reservation.setRestaurant(restaurant);
        Reservation savedReservation = reservationRepository.save(reservation);

        try {
            incrementReservationCount(clientId);
        } catch (Exception e) {
            throw new RuntimeException("Error", e);
        }

        restaurant.setAvailableSeats(restaurant.getAvailableSeats() - reservationDto.getPeopleNumber());
        restaurantRepository.save(restaurant);

        Map<String, String> reservationDetails = new HashMap<>();
        reservationDetails.put("date", reservation.getReservationTime().toString());
        reservationDetails.put("time", reservation.getReservationTime().toString());
        reservationDetails.put("restaurant", reservation.getRestaurant().getName());

        NotificationRequestDto notificationRequestDto = new NotificationRequestDto("RESERVATION_SUCCESS",reservation.getEmail(),reservationDetails);


        rabbitTemplate.convertAndSend("notifications-exchange","notifications-key",notificationRequestDto.toString());


        return reservationMapper.getDtoFromDomain(savedReservation);
    }
    @Override
    public boolean cancelReservation(Long reservationId, boolean canceledByRestaurant) {
        Reservation reservation = reservationRepository.findById(reservationId)
                .orElseThrow(() -> new RuntimeException("Reservation not found"));

        if (canceledByRestaurant) {
            Restaurant restaurant = reservation.getRestaurant();
            if (restaurant != null) {
                restaurant.setSeats(restaurant.getAvailableSeats() + reservation.getPeopleNumber());
                restaurantRepository.save(restaurant);
            }
        } else {
            try {
                ReservationDto reservationDto = reservationMapper.getDtoFromDomain(reservation);
                decrementReservationCount(reservationDto.getClientId());
                Restaurant restaurant = reservation.getRestaurant();
                restaurant.setSeats(restaurant.getAvailableSeats() + reservation.getPeopleNumber());
                restaurantRepository.save(restaurant);
            } catch (Exception e) {
                throw new RuntimeException("Failed to notify user service about reservation cancellation", e);
            }
        }

        reservationRepository.delete(reservation);
        return true;
    }

    public List<ReservationDto> getReservationsByEmail(String email) {
        List<Reservation> reservations = reservationRepository.findByEmail(email);

        return reservations.stream()
                .map(reservationMapper::getDtoFromDomain)
                .collect(Collectors.toList());
    }


    @Override
    public List<ReservationDto> getReservationsForRestaurant(Long restaurantId) {
        List<Reservation> reservations;

        if (restaurantId == null || !restaurantRepository.existsById(restaurantId)) {
            reservations = reservationRepository.findAll();
        } else {
            Restaurant restaurant = restaurantRepository.findById(restaurantId)
                    .orElseThrow(() -> new RuntimeException("Restaurant not found"));
            reservations = reservationRepository.findByRestaurant(restaurant);
        }

        return reservations.stream()
                .map(reservationMapper::getDtoFromDomain)
                .collect(Collectors.toList());
    }


    @Override
    public List<AvailableTermDto> getAvailableTerms(Long restaurantId, LocalDateTime startTime, LocalDateTime endTime) {
        Restaurant restaurant = restaurantRepository.findById(restaurantId)
                .orElseThrow(() -> new RuntimeException("Restaurant not found"));

        List<AvailableTerm> terms = availableTermRepository.findAvailableTermsByTime(restaurant, startTime);

        List<AvailableTermDto> availableTerms = terms.stream()
                .filter(term -> term.getStartTime().isBefore(endTime) && term.getEndTime().isAfter(startTime))
                .map(term -> {
                    AvailableTermDto dto = new AvailableTermDto();
                    dto.setStartTime(term.getStartTime());
                    dto.setEndTime(term.getEndTime());
                    dto.setAvailable(true);
                    dto.setNumberOfSeats(term.getNumberOfSeats());
                    dto.setZone(term.getZone());
                    return dto;
                })
                .collect(Collectors.toList());

        return availableTerms;
    }


    private Integer getReservationCount(Long clientId) {
        String url = "/client/" + clientId + "/reservations/count";
        ResponseEntity<Integer> response = userServiceRestTemplate.getForEntity(url, Integer.class);
        return response.getBody();
    }

    private void incrementReservationCount(Long clientId) {
        String url = "/client/" + clientId + "/reservations/increment";
        userServiceRestTemplate.postForEntity(url, null, Void.class);
    }

    private void decrementReservationCount(Long clientId) {
        String url = "/client/" + clientId + "/reservations/decrement";
        userServiceRestTemplate.postForEntity(url, null, Void.class);
    }


}
