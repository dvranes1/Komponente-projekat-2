package com.example.Komponente_servis2.domain;

public enum CuisineType {
    ITALIAN,CHINESE,SERBIAN,GREEK,KOREAN;
}
