package com.example.Komponente_servis2.service;

import com.example.Komponente_servis2.dto.AvailableTermDto;
import com.example.Komponente_servis2.dto.ReservationDto;

import java.time.LocalDateTime;
import java.util.List;

public interface ReservationService {
    ReservationDto createReservation(ReservationDto reservationDto);

    boolean cancelReservation(Long reservationId, boolean canceledByRestaurant);

    List<ReservationDto> getReservationsForRestaurant(Long restaurantId);

    List<AvailableTermDto> getAvailableTerms(Long restaurantId, LocalDateTime startTime, LocalDateTime endTime);
    List<ReservationDto> getReservationsByEmail(String email);
}
