package com.example.Komponente_servis2.service.Impl;

import com.example.Komponente_servis2.domain.AvailableTerm;
import com.example.Komponente_servis2.domain.CuisineType;
import com.example.Komponente_servis2.domain.RestaurantZone;
import com.example.Komponente_servis2.dto.AvailableTermDto;
import com.example.Komponente_servis2.dto.CreateAvailableTermDto;
import com.example.Komponente_servis2.mapper.AvailableTermMapper;
import com.example.Komponente_servis2.repository.AvailableTermRepository;
import com.example.Komponente_servis2.repository.RestaurantRepository;
import com.example.Komponente_servis2.service.AvailableTermService;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.List;
import java.util.stream.Collectors;

@Service
public class AvailableTermServiceImpl implements AvailableTermService {
    private final AvailableTermRepository availableTermRepository;
    private final AvailableTermMapper availableTermMapper;

    public AvailableTermServiceImpl(AvailableTermRepository availableTermRepository, AvailableTermMapper availableTermMapper) {
        this.availableTermRepository = availableTermRepository;
        this.availableTermMapper = availableTermMapper;
    }


    @Override
    public AvailableTermDto addAvailableTerm(CreateAvailableTermDto createAvailableTermDto) {
        AvailableTerm availableTerm = availableTermMapper.getDomainFromDto(createAvailableTermDto);
       AvailableTerm savedTerm =  availableTermRepository.save(availableTerm);

        AvailableTermDto availableTermDto = new AvailableTermDto();
        availableTermDto.setAvailable(savedTerm.isAvailable());
        availableTermDto.setZone(savedTerm.getZone());
        availableTermDto.setNumberOfSeats(savedTerm.getNumberOfSeats());
        availableTermDto.setStartTime(savedTerm.getStartTime());
        availableTermDto.setEndTime(savedTerm.getEndTime());
        return availableTermDto;
    }

    @Override
    public AvailableTermDto updateAvailableTerm(Long id, CreateAvailableTermDto availableTermDto) {
        AvailableTerm term = availableTermRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Available term not found"));

        term.setAvailable(availableTermDto.isAvailable());
        term.setZone(availableTermDto.getZone());
        term.setNumberOfSeats(availableTermDto.getNumberOfSeats());
        term.setStartTime(availableTermDto.getStartTime());
        term.setEndTime(availableTermDto.getEndTime());
        term.setZone(availableTermDto.getZone());

        AvailableTerm savedTerm =  availableTermRepository.save(term);
        AvailableTermDto updatedAvailableTermDto = new AvailableTermDto();
        updatedAvailableTermDto.setAvailable(savedTerm.isAvailable());
        updatedAvailableTermDto.setZone(savedTerm.getZone());
        updatedAvailableTermDto.setNumberOfSeats(savedTerm.getNumberOfSeats());
        updatedAvailableTermDto.setStartTime(savedTerm.getStartTime());
        updatedAvailableTermDto.setEndTime(savedTerm.getEndTime());
        return updatedAvailableTermDto;
    }

    @Override
    public List<AvailableTermDto> getAvailableTerms(Long restaurantId, RestaurantZone zone, CuisineType cuisineType,
                                                    String location, Integer numberOfPeople, LocalDateTime startTime, LocalDateTime endTime) {
        List<AvailableTerm> terms = availableTermRepository.findAvailableTerms(
                restaurantId, zone, cuisineType, location, numberOfPeople, startTime, endTime);

        return terms.stream()
                .map(availableTermMapper::getDtoFromDomain)
                .collect(Collectors.toList());
    }




}
