package com.example.Komponente_servis2.runner;

import com.example.Komponente_servis2.domain.CuisineType;
import com.example.Komponente_servis2.domain.Restaurant;
import com.example.Komponente_servis2.repository.RestaurantRepository;
import org.springframework.amqp.rabbit.core.RabbitAdmin;
import org.springframework.amqp.rabbit.core.RabbitTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class AppRunner {

    @Autowired
    private RestaurantRepository restaurantRepository;
    @Autowired
    private RabbitAdmin rabbitAdmin;

    @Bean
    CommandLineRunner loadData() {
        return args -> {
            Restaurant restaurant1 = new Restaurant("Di-Napoli", "Milutina Milankovica", "Italian cuisine", 10, "9:00-22:00", CuisineType.ITALIAN,10);
            Restaurant restaurant2 = new Restaurant("Shushirito", "Paje Maljevic", "Japanese cuisine", 8, "10:00-21:00", CuisineType.CHINESE,8);
            restaurantRepository.save(restaurant1);
            restaurantRepository.save(restaurant2);

            rabbitAdmin.initialize();
        };
    };
}

