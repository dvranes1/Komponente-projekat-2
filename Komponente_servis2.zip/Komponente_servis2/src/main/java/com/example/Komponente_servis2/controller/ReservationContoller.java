package com.example.Komponente_servis2.controller;

import com.example.Komponente_servis2.dto.AvailableTermDto;
import com.example.Komponente_servis2.dto.ReservationDto;
import com.example.Komponente_servis2.security.CheckSecurity;
import com.example.Komponente_servis2.security.service.impl.TokenServiceImpl;
import com.example.Komponente_servis2.service.ReservationService;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDateTime;
import java.util.List;

@RestController
@RequestMapping("/reservation")
public class ReservationContoller {

    private final ReservationService reservationService;
    private final TokenServiceImpl tokenServiceImpl;

    public ReservationContoller(ReservationService reservationService, TokenServiceImpl tokenServiceImpl) {
        this.reservationService = reservationService;
        this.tokenServiceImpl = tokenServiceImpl;
    }
    @CrossOrigin(origins = "http://localhost:5173")
    @CheckSecurity(roles = {"CLIENT"})
    @PostMapping
    public ResponseEntity<ReservationDto> createReservation(@RequestHeader("Authorization") String authorization,@RequestBody ReservationDto reservationDto) {
        ReservationDto createdReservation = reservationService.createReservation(reservationDto);
        return ResponseEntity.status(HttpStatus.CREATED).body(createdReservation);
    }
    @CrossOrigin(origins = "http://localhost:5173")
    @CheckSecurity(roles = {"CLIENT", "MANAGER"})
    @DeleteMapping("/cancel/{id}")
    public ResponseEntity<String> cancelReservation(
            @RequestHeader("Authorization") String authorization,
            @PathVariable Long id,
            @RequestParam boolean canceledByRestaurant) {
        boolean isCanceled = reservationService.cancelReservation(id, canceledByRestaurant);
        if (isCanceled) {
            return ResponseEntity.ok("Reservation canceled successfully");
        } else {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body("Failed to cancel reservation");
        }
    }

    @GetMapping("/list/{restaurantId}")
    public ResponseEntity<List<ReservationDto>> getReservationsForRestaurant(@PathVariable Long restaurantId) {
        List<ReservationDto> reservations = reservationService.getReservationsForRestaurant(restaurantId);
        return ResponseEntity.ok(reservations);
    }

    @GetMapping("/availableterms/{restaurantId}")
    public ResponseEntity<List<AvailableTermDto>> getAvailableTerms(
            @PathVariable Long restaurantId,
            @RequestParam LocalDateTime startTime,
            @RequestParam LocalDateTime endTime) {
        List<AvailableTermDto> availableTerms = reservationService.getAvailableTerms(restaurantId, startTime, endTime);
        return ResponseEntity.ok(availableTerms);
    }
    @CrossOrigin(origins = "http://localhost:5173")
    @CheckSecurity(roles = {"CLIENT"})
    @GetMapping("/client/reservations")
    public ResponseEntity<List<ReservationDto>> getReservationsByEmail(
            @RequestHeader("Authorization") String authorization) {
        String email = tokenServiceImpl.extractEmail(authorization);

        List<ReservationDto> reservations = reservationService.getReservationsByEmail(email);

        return ResponseEntity.ok(reservations);
    }

}
