package com.example.Komponente_servis2.dto;

import com.example.Komponente_servis2.domain.RestaurantZone;

import java.time.LocalDateTime;

public class ReservationDto {

    private Long clientId;
    private Long idRezervacije;
    private Long restaurantId;
    private LocalDateTime reservationTime;
    private int peopleNumber;
    private RestaurantZone zone;
    private String email;

    public ReservationDto(Long clientId, Long idRezervacije, Long restaurantId, LocalDateTime reservationTime, int peopleNumber, RestaurantZone zone,String email) {
        this.clientId = clientId;
        this.idRezervacije = idRezervacije;
        this.restaurantId = restaurantId;
        this.reservationTime = reservationTime;
        this.peopleNumber = peopleNumber;
        this.zone = zone;
        this.email = email;
    }

    public ReservationDto() {

    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public Long getClientId() {
        return clientId;
    }

    public void setClientId(Long clientId) {
        this.clientId = clientId;
    }

    public Long getIdRezervacije() {
        return idRezervacije;
    }

    public void setIdRezervacije(Long idRezervacije) {
        this.idRezervacije = idRezervacije;
    }

    public Long getRestaurantId() {
        return restaurantId;
    }

    public void setRestaurantId(Long restaurantId) {
        this.restaurantId = restaurantId;
    }

    public LocalDateTime getReservationTime() {
        return reservationTime;
    }

    public void setReservationTime(LocalDateTime reservationTime) {
        this.reservationTime = reservationTime;
    }

    public int getPeopleNumber() {
        return peopleNumber;
    }

    public void setPeopleNumber(int peopleNumber) {
        this.peopleNumber = peopleNumber;
    }

    public RestaurantZone getZone() {
        return zone;
    }

    public void setZone(RestaurantZone zone) {
        this.zone = zone;
    }
}
