package com.example.Komponente_servis2.service;

import com.example.Komponente_servis2.domain.CuisineType;
import com.example.Komponente_servis2.dto.RestaurantDto;

import java.util.List;

public interface RestaurantService {
    RestaurantDto addRestaurant(RestaurantDto restaurantDto);

    RestaurantDto updateRestaurant(Long id, RestaurantDto restaurantDto);

    List<RestaurantDto> getRestaurants(CuisineType cuisineType, String location);

}
