package com.example.Komponente_servis2.mapper;

import com.example.Komponente_servis2.domain.AvailableTerm;
import com.example.Komponente_servis2.domain.Restaurant;
import com.example.Komponente_servis2.dto.AvailableTermDto;
import com.example.Komponente_servis2.dto.CreateAvailableTermDto;
import com.example.Komponente_servis2.repository.AvailableTermRepository;
import com.example.Komponente_servis2.repository.RestaurantRepository;
import jakarta.persistence.EntityNotFoundException;
import org.springframework.stereotype.Component;

@Component
public class AvailableTermMapper {

    private final RestaurantRepository restaurantRepository;

    public AvailableTermMapper(RestaurantRepository restaurantRepository) {
        this.restaurantRepository = restaurantRepository;
    }

    public AvailableTerm getDomainFromDto(CreateAvailableTermDto dto) {
        AvailableTerm term = new AvailableTerm();
        Restaurant restaurant = restaurantRepository.findById(dto.getRestaurantId())
                .orElseThrow(() -> new EntityNotFoundException("Restaurant not found with id: " + dto.getRestaurantId()));

        term.setRestaurant(restaurant);
        term.setZone(dto.getZone());
        term.setAvailable(dto.isAvailable());
        term.setNumberOfSeats(dto.getNumberOfSeats());
        term.setStartTime(dto.getStartTime());
        term.setEndTime(dto.getEndTime());
        return term;

    }

    public AvailableTermDto getDtoFromDomain(AvailableTerm domain) {
        AvailableTermDto dto = new AvailableTermDto();
        dto.setNumberOfSeats(domain.getNumberOfSeats());
        dto.setStartTime(domain.getStartTime());
        dto.setEndTime(domain.getEndTime());
        dto.setZone(domain.getZone());
        dto.setAvailable(domain.isAvailable());

        return dto;
    }
}
