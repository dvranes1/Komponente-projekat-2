package com.example.Komponente_servis2.mapper;

import com.example.Komponente_servis2.domain.Reservation;
import com.example.Komponente_servis2.domain.Restaurant;
import com.example.Komponente_servis2.dto.ReservationDto;
import org.springframework.stereotype.Component;

@Component
public class ReservationMapper {

    public ReservationDto getDtoFromDomain(Reservation reservation) {
        ReservationDto reservationDto = new ReservationDto();
        reservationDto.setIdRezervacije(reservation.getId());
        reservationDto.setRestaurantId(reservation.getRestaurant() != null ? reservation.getRestaurant().getId() : null);
        reservationDto.setReservationTime(reservation.getReservationTime());
        reservationDto.setPeopleNumber(reservation.getPeopleNumber());
        reservationDto.setZone(reservation.getZone());
        reservationDto.setClientId(reservation.getClientId());
        reservationDto.setEmail(reservation.getEmail());
        return reservationDto;
    }

    public Reservation getDomainFromDto(ReservationDto reservationDto) {
        Reservation reservation = new Reservation();
        reservation.setId(reservationDto.getIdRezervacije());
        reservation.setReservationTime(reservationDto.getReservationTime());
        reservation.setPeopleNumber(reservationDto.getPeopleNumber());
        reservation.setZone(reservationDto.getZone());
        reservation.setClientId(reservationDto.getClientId());
        reservation.setEmail(reservationDto.getEmail());
        reservation.setConfirmed(false);

        if (reservationDto.getRestaurantId() != null) {
            Restaurant restaurant = new Restaurant();
            restaurant.setId(reservationDto.getRestaurantId());
            reservation.setRestaurant(restaurant);
        }
        return reservation;
    }

    public ReservationMapper(){

    }
}
