package com.example.Komponente_servis2.dto;

import com.example.Komponente_servis2.domain.RestaurantZone;

import java.time.LocalDateTime;

public class AvailableTermDto {
    private int numberOfSeats;
    private RestaurantZone zone;
    private LocalDateTime startTime;
    private LocalDateTime endTime;
    private boolean available;


    public AvailableTermDto() {
    }

    public AvailableTermDto(int numberOfSeats, RestaurantZone zone, LocalDateTime startTime, LocalDateTime endTime, boolean available) {

        this.numberOfSeats = numberOfSeats;
        this.zone = zone;
        this.startTime = startTime;
        this.endTime = endTime;
        this.available = available;
    }


    public int getNumberOfSeats() {
        return numberOfSeats;
    }

    public void setNumberOfSeats(int numberOfSeats) {
        this.numberOfSeats = numberOfSeats;
    }

    public RestaurantZone getZone() {
        return zone;
    }

    public void setZone(RestaurantZone zone) {
        this.zone = zone;
    }

    public LocalDateTime getStartTime() {
        return startTime;
    }

    public void setStartTime(LocalDateTime startTime) {
        this.startTime = startTime;
    }

    public LocalDateTime getEndTime() {
        return endTime;
    }

    public void setEndTime(LocalDateTime endTime) {
        this.endTime = endTime;
    }

    public boolean isAvailable() {
        return available;
    }

    public void setAvailable(boolean available) {
        this.available = available;
    }
}
