package com.example.Komponente_servis2.service.Impl;

import com.example.Komponente_servis2.domain.CuisineType;
import com.example.Komponente_servis2.domain.Restaurant;
import com.example.Komponente_servis2.dto.RestaurantDto;
import com.example.Komponente_servis2.mapper.RestaurantMapper;
import com.example.Komponente_servis2.repository.RestaurantRepository;
import com.example.Komponente_servis2.service.RestaurantService;
import jakarta.transaction.Transactional;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

@Service
@Transactional
public class RestaurantServiceImpl implements RestaurantService {
    private final RestaurantRepository restaurantRepository;
    private final RestaurantMapper restaurantMapper;

    public RestaurantServiceImpl(RestaurantRepository restaurantRepository, RestaurantMapper restaurantMapper) {
        this.restaurantRepository = restaurantRepository;
        this.restaurantMapper = restaurantMapper;
    }

    @Override
    public RestaurantDto addRestaurant(RestaurantDto restaurantDto) {
        Restaurant restaurant =  restaurantMapper.getDomainFromDto(restaurantDto);
        Restaurant savedRestaurant = restaurantRepository.save(restaurant);


        RestaurantDto savedRestaurantDto = new RestaurantDto();
        savedRestaurantDto.setId(savedRestaurant.getId());
        savedRestaurantDto.setName(savedRestaurant.getName());
        savedRestaurantDto.setAddress(savedRestaurant.getAddress());
        savedRestaurantDto.setDescription(savedRestaurant.getDescription());
        savedRestaurantDto.setNumberOfTables(savedRestaurant.getSeats());
        savedRestaurantDto.setOpenHours(savedRestaurant.getOpenHours());
        savedRestaurantDto.setCuisineType(savedRestaurant.getCuisineType());
        return savedRestaurantDto;
    }

    @Override
    public RestaurantDto updateRestaurant(Long id, RestaurantDto restaurantDto) {
        Restaurant restaurant = restaurantRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Restaurant not found"));
        restaurant.setName(restaurantDto.getName());
        restaurant.setAddress(restaurantDto.getAddress());
        restaurant.setDescription(restaurantDto.getDescription());
        restaurant.setSeats(restaurantDto.getNumberOfTables());
        restaurant.setOpenHours(restaurantDto.getOpenHours());
        restaurant.setCuisineType(restaurantDto.getCuisineType());
        Restaurant updatedRestaurant =  restaurantRepository.save(restaurant);
        RestaurantDto responseDto = new RestaurantDto();
        responseDto.setId(updatedRestaurant.getId());
        responseDto.setName(updatedRestaurant.getName());
        responseDto.setAddress(updatedRestaurant.getAddress());
        responseDto.setDescription(updatedRestaurant.getDescription());
        responseDto.setNumberOfTables(updatedRestaurant.getSeats());
        responseDto.setOpenHours(updatedRestaurant.getOpenHours());
        responseDto.setCuisineType(updatedRestaurant.getCuisineType());
        return responseDto;
    }


    @Override
    public List<RestaurantDto> getRestaurants(CuisineType cuisineType, String location) {
        List<Restaurant> restaurants = restaurantRepository.findByCuisineTypeAndAddress(cuisineType, location);
        return restaurants.stream()
                .map(restaurantMapper::getDtoFromDomain)
                .collect(Collectors.toList());
    }



}
