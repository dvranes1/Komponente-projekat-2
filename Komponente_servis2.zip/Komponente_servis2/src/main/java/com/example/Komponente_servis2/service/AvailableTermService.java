package com.example.Komponente_servis2.service;

import com.example.Komponente_servis2.domain.CuisineType;
import com.example.Komponente_servis2.domain.RestaurantZone;
import com.example.Komponente_servis2.dto.AvailableTermDto;
import com.example.Komponente_servis2.dto.CreateAvailableTermDto;

import java.time.LocalDateTime;
import java.util.List;

public interface AvailableTermService {
    AvailableTermDto addAvailableTerm(CreateAvailableTermDto createAvailableTermDto);
    AvailableTermDto updateAvailableTerm(Long id, CreateAvailableTermDto availableTermDto);
    List<AvailableTermDto> getAvailableTerms(Long restaurantId, RestaurantZone zone, CuisineType cuisineType,
                                             String location, Integer numberOfPeople, LocalDateTime startTime, LocalDateTime endTime);
}
