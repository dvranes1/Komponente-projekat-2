package com.example.Komponente_servis2.repository;

import com.example.Komponente_servis2.domain.AvailableTerm;
import com.example.Komponente_servis2.domain.CuisineType;
import com.example.Komponente_servis2.domain.Restaurant;
import com.example.Komponente_servis2.domain.RestaurantZone;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.time.LocalDateTime;
import java.util.List;

@Repository
public interface AvailableTermRepository extends JpaRepository<AvailableTerm, Long> {

    @Query("SELECT t FROM AvailableTerm t " +
            "WHERE (:restaurantId IS NULL OR t.restaurant.id = :restaurantId) " +
            "AND (:zone IS NULL OR t.zone = :zone) " +
            "AND (:cuisineType IS NULL OR t.restaurant.cuisineType = :cuisineType) " +
            "AND (:location IS NULL OR t.restaurant.address = :location) " +
            "AND (:numberOfPeople IS NULL OR t.numberOfSeats >= :numberOfPeople) " +
            "AND (:startTime IS NULL OR t.startTime >= :startTime) " +
            "AND (:endTime IS NULL OR t.endTime <= :endTime)")
    List<AvailableTerm> findAvailableTerms(@Param("restaurantId") Long restaurantId,
                                           @Param("zone") RestaurantZone zone,
                                           @Param("cuisineType") CuisineType cuisineType,
                                           @Param("location") String location,
                                           @Param("numberOfPeople") Integer numberOfPeople,
                                           @Param("startTime") LocalDateTime startTime,
                                           @Param("endTime") LocalDateTime endTime);

    @Query("SELECT t FROM AvailableTerm t WHERE t.restaurant = :restaurant AND :startTime BETWEEN t.startTime AND t.endTime")
    List<AvailableTerm> findAvailableTermsByTime(Restaurant restaurant, LocalDateTime startTime);

}
