package com.example.Komponente_servis2.repository;

import com.example.Komponente_servis2.domain.CuisineType;
import com.example.Komponente_servis2.domain.Restaurant;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface RestaurantRepository extends JpaRepository<Restaurant, Long> {

    @Query("SELECT r FROM Restaurant r WHERE " +
            "(:cuisineType IS NULL OR r.cuisineType = :cuisineType) AND " +
            "(:location IS NULL OR LOWER(r.address) LIKE LOWER(CONCAT('%', :location, '%')))")
    List<Restaurant> findByCuisineTypeAndAddress(@Param("cuisineType") CuisineType cuisineType,
                                                 @Param("location") String location);
}
