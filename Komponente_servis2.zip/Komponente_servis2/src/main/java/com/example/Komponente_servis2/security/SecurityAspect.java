package com.example.Komponente_servis2.security;

import com.example.Komponente_servis2.security.service.TokenService;
import io.jsonwebtoken.Claims;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.reflect.MethodSignature;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import java.lang.reflect.Method;
import java.util.Arrays;

@Aspect
@Configuration
public class SecurityAspect {

    private final TokenService tokenService;

    public SecurityAspect(TokenService tokenService) {
        this.tokenService = tokenService;
    }

    @Around("@annotation(com.example.Komponente_servis2.security.CheckSecurity)")
    public Object around(ProceedingJoinPoint joinPoint) throws Throwable {
        MethodSignature methodSignature = (MethodSignature) joinPoint.getSignature();
        Method method = methodSignature.getMethod();


        String token = null;
        Object[] args = joinPoint.getArgs();
        String[] parameterNames = methodSignature.getParameterNames();

        for (int i = 0; i < parameterNames.length; i++) {
            if ("authorization".equalsIgnoreCase(parameterNames[i]) && args[i] instanceof String) {
                String headerValue = (String) args[i];
                if (headerValue.startsWith("Bearer ")) {
                    token = headerValue.substring(7).trim();
                }
            }
        }

        if (token == null || token.isEmpty()) {
            return new ResponseEntity<>("Missing or invalid token", HttpStatus.UNAUTHORIZED);
        }

        if (!token.matches("[a-zA-Z0-9-_]+\\.[a-zA-Z0-9-_]+\\.[a-zA-Z0-9-_]+")) {
            return new ResponseEntity<>("Invalid token format", HttpStatus.UNAUTHORIZED);
        }

        Claims claims;
        try {
            claims = tokenService.parseToken(token);
            if (claims == null) {
                throw new RuntimeException("Token claims are null");
            }
        } catch (Exception e) {
            throw new RuntimeException("Failed to parse token: " + e.getMessage());
        }


        CheckSecurity checkSecurity = method.getAnnotation(CheckSecurity.class);
        String role = claims.get("role", String.class);
        if (role == null) {
            return new ResponseEntity<>("Role not found in token", HttpStatus.FORBIDDEN);
        }

        if (!Arrays.asList(checkSecurity.roles()).contains(role)) {
            return new ResponseEntity<>("Access denied", HttpStatus.FORBIDDEN);
        }

        return joinPoint.proceed();
    }
}