package com.example.Komponente_servis2.dto;

import com.example.Komponente_servis2.domain.CuisineType;

public class RestaurantDto {

    private Long id;
    private String name;
    private String address;
    private String description;
    private int numberOfTables;
    private String openHours;
    private CuisineType cuisineType;

    public RestaurantDto(Long id, String name, String address, String description, int numberOfTables, String openHours, CuisineType cuisineType) {
        this.id = id;
        this.name = name;
        this.address = address;
        this.description = description;
        this.numberOfTables = numberOfTables;
        this.openHours = openHours;
        this.cuisineType = cuisineType;
    }
    public RestaurantDto() {

    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public int getNumberOfTables() {
        return numberOfTables;
    }

    public void setNumberOfTables(int numberOfTables) {
        this.numberOfTables = numberOfTables;
    }

    public String getOpenHours() {
        return openHours;
    }

    public void setOpenHours(String openHours) {
        this.openHours = openHours;
    }

    public CuisineType getCuisineType() {
        return cuisineType;
    }

    public void setCuisineType(CuisineType cuisineType) {
        this.cuisineType = cuisineType;
    }
}
