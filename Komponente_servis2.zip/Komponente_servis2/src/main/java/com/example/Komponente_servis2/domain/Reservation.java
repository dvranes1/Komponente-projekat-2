package com.example.Komponente_servis2.domain;

import jakarta.persistence.*;

import java.time.LocalDateTime;

@Entity
public class Reservation extends BaseEntity {


    @ManyToOne
    @JoinColumn(name = "restaurant_id")
    private Restaurant restaurant;
    private int peopleNumber;
    @Column(name = "reservation_time")
    private LocalDateTime reservationTime;
    @Enumerated(EnumType.STRING)
    private RestaurantZone zone;
    private boolean confirmed;
    private Long clientId;
    private String email;

    public Reservation(Long id, Restaurant restaurant, int peopleNumber, LocalDateTime reservationTime, RestaurantZone zone, boolean confirmed, Long clientId,String email) {
        super(id);
        this.restaurant = restaurant;
        this.peopleNumber = peopleNumber;
        this.reservationTime = reservationTime;
        this.zone = zone;
        this.confirmed = confirmed;
        this.clientId = clientId;
        this.email = email;
    }

    public Reservation() {

    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public Restaurant getRestaurant() {
        return restaurant;
    }

    public void setRestaurant(Restaurant restaurant) {
        this.restaurant = restaurant;
    }

    public int getPeopleNumber() {
        return peopleNumber;
    }

    public void setPeopleNumber(int peopleNumber) {
        this.peopleNumber = peopleNumber;
    }

    public LocalDateTime getReservationTime() {
        return reservationTime;
    }

    public void setReservationTime(LocalDateTime reservationTime) {
        this.reservationTime = reservationTime;
    }

    public RestaurantZone getZone() {
        return zone;
    }

    public void setZone(RestaurantZone zone) {
        this.zone = zone;
    }

    public boolean isConfirmed() {
        return confirmed;
    }

    public void setConfirmed(boolean confirmed) {
        this.confirmed = confirmed;
    }

    public long getClientId() {
        return clientId;
    }

    public void setClientId(Long clientId) {
        this.clientId = clientId;
    }
}
