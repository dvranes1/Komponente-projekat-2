package com.example.Komponente_servis2;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication(scanBasePackages = "com.example.Komponente_servis2")
public class KomponenteServis2Application {

	public static void main(String[] args) {
		SpringApplication.run(KomponenteServis2Application.class, args);
	}

}
