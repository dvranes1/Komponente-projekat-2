package com.example.Komponente_servis2.mapper;

import com.example.Komponente_servis2.domain.Restaurant;
import com.example.Komponente_servis2.dto.RestaurantDto;
import org.springframework.stereotype.Component;

@Component
public class RestaurantMapper {

    public RestaurantDto getDtoFromDomain(Restaurant restaurant) {
        RestaurantDto dto = new RestaurantDto();
        dto.setId(restaurant.getId());
        dto.setName(restaurant.getName());
        dto.setAddress(restaurant.getAddress());
        dto.setDescription(restaurant.getDescription());
        dto.setNumberOfTables(restaurant.getSeats());
        dto.setOpenHours(restaurant.getOpenHours());
        dto.setCuisineType(restaurant.getCuisineType());
        return dto;
    }

    public Restaurant getDomainFromDto(RestaurantDto dto) {
        Restaurant restaurant = new Restaurant();
        restaurant.setId(dto.getId());
        restaurant.setName(dto.getName());
        restaurant.setAvailableSeats(dto.getNumberOfTables());
        restaurant.setAddress(dto.getAddress());
        restaurant.setDescription(dto.getDescription());
        restaurant.setSeats(dto.getNumberOfTables());
        restaurant.setOpenHours(dto.getOpenHours());
        restaurant.setCuisineType(dto.getCuisineType());
        return restaurant;
    }
}
