package com.example.Komponente_servis2.controller;

import com.example.Komponente_servis2.domain.CuisineType;
import com.example.Komponente_servis2.domain.RestaurantZone;
import com.example.Komponente_servis2.dto.AvailableTermDto;
import com.example.Komponente_servis2.dto.CreateAvailableTermDto;
import com.example.Komponente_servis2.security.CheckSecurity;
import com.example.Komponente_servis2.service.AvailableTermService;
import com.example.Komponente_servis2.service.RestaurantService;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.util.List;

@RestController
@RequestMapping("/availableterms")
public class AvailableTermController {

    private final AvailableTermService availableTermService;

    public AvailableTermController(AvailableTermService availableTermService) {
        this.availableTermService = availableTermService;
    }

    @CheckSecurity(roles = {"MANAGER"})
    @PostMapping()
    public ResponseEntity<AvailableTermDto> addNewTerm(@RequestHeader("Authorization") String authorization, @RequestBody CreateAvailableTermDto termDto) {
        AvailableTermDto newTerm =  availableTermService.addAvailableTerm(termDto);
        return new ResponseEntity<>(newTerm, HttpStatus.CREATED);
    }
    @CheckSecurity(roles = {"MANAGER"})
    @PutMapping("/update/{id}")
    public ResponseEntity<String> updateTerm(@RequestHeader("Authorization") String authorization,@PathVariable Long id, @RequestBody CreateAvailableTermDto createAvailableTermDto) {
        AvailableTermDto newTerm = availableTermService.updateAvailableTerm(id, createAvailableTermDto);
        return new ResponseEntity<>(newTerm.toString(), HttpStatus.OK);
    }
    @CheckSecurity(roles = {"CLIENT"})
    @GetMapping("/availableterms")
    public ResponseEntity<List<AvailableTermDto>> getAvailableTerms(
            @RequestHeader("Authorization") String authorization,
            @RequestParam(required = false) Long restaurantId,
            @RequestParam(required = false) RestaurantZone zone,
            @RequestParam(required = false) CuisineType cuisineType,
            @RequestParam(required = false) String location,
            @RequestParam(required = false) Integer numberOfPeople,
            @RequestParam(required = false) String startTime,
            @RequestParam(required = false) String endTime) {

        LocalDateTime parsedStartTime = null;
        LocalDateTime parsedEndTime = null;

        try {
            if (startTime != null) {
                parsedStartTime = LocalDateTime.parse(startTime, DateTimeFormatter.ISO_LOCAL_DATE_TIME);
            }
            if (endTime != null) {
                parsedEndTime = LocalDateTime.parse(endTime, DateTimeFormatter.ISO_LOCAL_DATE_TIME);
            }
        } catch (DateTimeParseException e) {
            throw new IllegalArgumentException("Invalid date or time format. Use 'YYYY-MM-DDTHH:mm:ss'.", e);
        }

        List<AvailableTermDto> terms = availableTermService.getAvailableTerms(
                restaurantId, zone, cuisineType, location, numberOfPeople, parsedStartTime, parsedEndTime);

        return ResponseEntity.ok(terms);
    }



}
