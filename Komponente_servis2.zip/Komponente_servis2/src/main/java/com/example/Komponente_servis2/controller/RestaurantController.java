package com.example.Komponente_servis2.controller;

import com.example.Komponente_servis2.domain.CuisineType;
import com.example.Komponente_servis2.dto.RestaurantDto;
import com.example.Komponente_servis2.security.CheckSecurity;
import com.example.Komponente_servis2.service.RestaurantService;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/restaurants")
public class RestaurantController {
    private final RestaurantService restaurantService;
    public RestaurantController(RestaurantService restaurantService) {
        this.restaurantService = restaurantService;
    }

    @CheckSecurity(roles = {"MANAGER"})
    @PostMapping
    public ResponseEntity<RestaurantDto> addRestaurant(@RequestHeader("Authorization") String authorization, @RequestBody RestaurantDto restaurantDto) {
        RestaurantDto backRestaurant = restaurantService.addRestaurant(restaurantDto);
        return new ResponseEntity<>(backRestaurant, HttpStatus.CREATED);
    }

    @CheckSecurity(roles = {"MANAGER"})
    @PutMapping("/update/{id}")
    public ResponseEntity<RestaurantDto> updateRestaurant(@RequestHeader("Authorization") String authorization,@PathVariable Long id, @RequestBody RestaurantDto restaurantDto) {
        RestaurantDto updated =  restaurantService.updateRestaurant(id, restaurantDto);
        return new ResponseEntity<>(updated, HttpStatus.CREATED);
    }

    @GetMapping("/list")
    public ResponseEntity<List<RestaurantDto>> listRestaurants(
            @RequestParam(required = false) CuisineType cuisineType,
            @RequestParam(required = false) String location) {
        List<RestaurantDto> restaurants = restaurantService.getRestaurants(cuisineType, location);
        return ResponseEntity.ok(restaurants);
    }


}
