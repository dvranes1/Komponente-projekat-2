package com.example.Komponente_servis2.security.service.impl;

import com.example.Komponente_servis2.security.service.TokenService;
import jakarta.annotation.PostConstruct;
import org.springframework.stereotype.Service;
import io.jsonwebtoken.Claims;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.security.Keys;

import java.security.Key;

@Service

public class TokenServiceImpl implements TokenService {
    private String secret = "Sedidjesinizadjesinijesisisisisisisisisisiiissisissisissisiss1234";

    private Key secretKey;

    @PostConstruct
    public void init() {
        this.secretKey = Keys.hmacShaKeyFor(secret.getBytes());
    }

    @Override
    public String generate(Claims claims) {
        return Jwts.builder()
                .setClaims(claims)
                .signWith(secretKey)
                .compact();
    }

    public Claims parseToken(String jwt) {
        try {
            String token = jwt.replace("Bearer ", "").trim();
            System.out.println("Token: " + token); // Provera tokena
            return Jwts.parserBuilder()
                    .setSigningKey(secretKey)
                    .build()
                    .parseClaimsJws(token)
                    .getBody();
        } catch (Exception e) {
            throw new RuntimeException("Invalid JWT token: " + e.getMessage());
        }
    }

    public String extractEmail(String jwt) {
        try {
            String token = jwt.replace("Bearer ", "").trim();
            Claims claims = Jwts.parserBuilder()
                    .setSigningKey(secretKey)
                    .build()
                    .parseClaimsJws(token)
                    .getBody();

            if (claims.containsKey("email")) {
                return claims.get("email").toString();
            } else {
                throw new RuntimeException("Email not found in token");
            }
        } catch (Exception e) {
            throw new RuntimeException("Invalid JWT token: " + e.getMessage());
        }
    }
}
